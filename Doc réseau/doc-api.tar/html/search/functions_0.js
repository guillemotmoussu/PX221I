var searchData=
[
  ['allocategameothello',['allocateGameOthello',['../user_network_8h.html#a0abce4f0e647e9801137a425e0bc36bf',1,'userNetwork.c']]]
];
