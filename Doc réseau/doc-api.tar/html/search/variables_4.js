var searchData=
[
  ['move',['move',['../structgame.html#ae1db0c29e0b82b9ba2c1fb28c8315275',1,'game']]],
  ['mycolor',['myColor',['../structgame.html#ade83a154432f08d5169f4945d2b6bfee',1,'game']]]
];
