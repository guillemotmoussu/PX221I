var searchData=
[
  ['waitmoveothello',['waitMoveOthello',['../user_network_8h.html#a22e69c0e9be79f6c74ec6ae4fd449588',1,'userNetwork.c']]],
  ['win',['WIN',['../user_network_8h.html#aa19be6305a5a4485e1e70de70ed7d677a843dff91ff0b0e5b98a110a512b2f531',1,'userNetwork.h']]]
];
