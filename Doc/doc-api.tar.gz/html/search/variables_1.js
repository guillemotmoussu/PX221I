var searchData=
[
  ['buf',['buf',['../structgame.html#aba6aae4ad012ab78acf837ae668d7037',1,'game']]]
];
