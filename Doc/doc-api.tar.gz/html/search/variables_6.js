var searchData=
[
  ['socket',['socket',['../structgame.html#a492f42644060141ff8cf3c835387d28f',1,'game']]],
  ['state',['state',['../structgame.html#abee3071b1ce76ff85031c13e65dca2c7',1,'game']]]
];
