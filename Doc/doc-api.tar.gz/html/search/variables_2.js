var searchData=
[
  ['currentplayer',['currentPlayer',['../structgame.html#ae63129705516d4bd557978d15e1c1961',1,'game']]]
];
