var searchData=
[
  ['address',['address',['../structgame.html#aa45a835d346b1cd310e412b03718676f',1,'game']]]
];
