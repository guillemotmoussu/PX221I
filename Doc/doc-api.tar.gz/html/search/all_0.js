var searchData=
[
  ['address',['address',['../structgame.html#aa45a835d346b1cd310e412b03718676f',1,'game']]],
  ['allocategameothello',['allocateGameOthello',['../user_network_8h.html#a0abce4f0e647e9801137a425e0bc36bf',1,'userNetwork.c']]]
];
