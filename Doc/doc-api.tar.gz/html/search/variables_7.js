var searchData=
[
  ['userid',['userId',['../structgame.html#a0dfc1fa2bd39677dbb9043267ab05b1f',1,'game']]]
];
