var searchData=
[
  ['socket',['socket',['../structgame.html#a492f42644060141ff8cf3c835387d28f',1,'game']]],
  ['startgameothello',['startGameOthello',['../user_network_8h.html#ad7e2f10d9e5e9d763911d6767c34203d',1,'userNetwork.c']]],
  ['state',['state',['../structgame.html#abee3071b1ce76ff85031c13e65dca2c7',1,'game']]],
  ['states',['states',['../user_network_8h.html#aa19be6305a5a4485e1e70de70ed7d677',1,'userNetwork.h']]]
];
