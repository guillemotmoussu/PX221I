var searchData=
[
  ['userid',['userId',['../structgame.html#a0dfc1fa2bd39677dbb9043267ab05b1f',1,'game']]],
  ['usernetwork_2eh',['userNetwork.h',['../user_network_8h.html',1,'']]]
];
